from flask import Flask, render_template, url_for, request, redirect, session

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Set a secret key for session management

# Sample data (replace with actual data handling)
questions_for_subject = {
    'ML': [
        "Define Machine Learning.",
        "Explain Decision tree and give algorithm."
    ],
    'CD': [
        "What is a parse tree.",
        "Explain Predictive parsing."
    ],
    'SL': [
        "Explain Arrays in Ruby.",
        "Explain the structure and execution of ruby program."
    ]
}

# Routes
@app.route('/')
def home():
    return render_template('student_interface.html', college_name='Your College')

@app.route('/join', methods=['POST'])
def join():
    student_name = request.form.get('student_name')
    student_id = request.form.get('student_id')
    subject = request.form.get('subject')
    session['student_name'] = student_name
    session['subject'] = subject
    session['question_index'] = 0  # Initialize question index in session
    session['answers'] = [''] * len(questions_for_subject.get(subject, []))  # Initialize answers list
    return render_template('join_exam.html', student_name=student_name, subject=subject)

@app.route('/validate_passcode', methods=['POST'])
def validate_passcode():
    passcode = request.form.get('passcode')
    if passcode == '12345':  # Replace with actual passcode validation logic
        return redirect(url_for('exam_portal'))
    else:
        return render_template('error.html', message='Invalid Passcode')

@app.route('/exam_portal')
def exam_portal():
    student_name = session.get('student_name')
    subject = session.get('subject')
    questions = questions_for_subject.get(subject, [])
    question_index = int(request.args.get('question_index', 0))  # Retrieve question_index from URL parameter
    current_question = questions[question_index] if questions else ""
    current_answer = session['answers'][question_index] if 'answers' in session else ""
    return render_template('exam_portal.html', student_name=student_name, subject=subject, questions=questions, question=current_question, question_index=question_index, answer=current_answer)

@app.route('/submit_answers', methods=['POST'])
def submit_answers():
    answer = request.form.get('answer')
    question_index = int(request.form.get('question_index'))
    session['answers'][question_index] = answer  # Store the answer in session
    session['question_index'] = question_index  # Update current question index in session
    return redirect(url_for('exam_portal'))

@app.route('/submit_exam', methods=['POST'])
def submit_exam():
    # Handle final submission of exam answers (not implemented in detail here)
    # Typically would involve saving answers to a database or file
    return render_template('submission_success.html')

if __name__ == '__main__':
    app.run(debug=True)
